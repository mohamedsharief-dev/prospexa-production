const {onRequest} = require("firebase-functions/v2/https");
const app = require("./src");

exports.api = onRequest(app);
