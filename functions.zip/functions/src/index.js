const express = require("express");
const businessRouter = require("./api/business"); // Updated this line

const app = express();

app.use("/businesses", businessRouter);

module.exports = app;
